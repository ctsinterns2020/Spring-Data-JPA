package ormlearn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Handson1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
