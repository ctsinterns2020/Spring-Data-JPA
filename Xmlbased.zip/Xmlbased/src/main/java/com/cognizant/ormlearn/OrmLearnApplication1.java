package com.cognizant.ormlearn;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cognizant.ormlearn.repository.*;

import com.cognizant.ormlearn.model.*;

@SpringBootApplication
public class OrmLearnApplication1 {
	public static void main(String[] args) {
		
				
				SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
				Session session =  sessionFactory.openSession();
		
				session.beginTransaction();
        
				Country1 con = new Country1("CN","China");
       // con.setName("China");
        		
				session.save(con);    
        
        		session.getTransaction().commit();
        		session.close();
	
	}
}

