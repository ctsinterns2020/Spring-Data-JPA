package com.cognizant.ormlearn.repository;


import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
//import org.hibernate.cfg.Configuration;
//import com.cognizant.ormlearn.model.*;
public class HibernateUtil {
	
    private static final SessionFactory sessionFactory = buildSessionFactory();
    
    private static SessionFactory buildSessionFactory() {
        try {        	
            
            // Create the SessionFactory from hibernate.cfg.xml 
            //Configuration configuration = new Configuration().configure("dbconfig.xml");     
       //return configuration.buildSessionFactory( new StandardServiceRegistryBuilder().applySettings( configuration.getProperties() ).build() );
        	
        	
        	StandardServiceRegistry standardServiceRegistry = new StandardServiceRegistryBuilder().configure("dbconfig1.xml").build();
        	Metadata metadata = new MetadataSources(standardServiceRegistry).getMetadataBuilder().build();
        	return metadata.getSessionFactoryBuilder().build();

            
        }
        catch (Throwable ex) {
            
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
	
}




