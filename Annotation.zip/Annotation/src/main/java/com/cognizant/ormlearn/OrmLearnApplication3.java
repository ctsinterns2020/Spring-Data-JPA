package com.cognizant.ormlearn;



//import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cognizant.ormlearn.repository.*;

import com.cognizant.ormlearn.model.Country;

@SpringBootApplication
public class OrmLearnApplication3 {
	public static void main(String[] args) {
		
				
				SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
				Session session =  sessionFactory.openSession();
		
				session.beginTransaction();
        
				Country con = new Country("EU","Europe");
       // con.setName("China");
        		
				session.save(con);    
        
        		session.getTransaction().commit();
        		session.close();
	
	}
}

